import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>Your first Angular 2 app</h1>'
})
export class AppComponent { }
